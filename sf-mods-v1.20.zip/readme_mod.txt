
## SF Mods for Life is Feudal ##

* Website	http://skunkfu.net/sf-mods/
* Legends	Rusty, Lily, Kenshy & Thorn
* Credit	Ellian

A collection of tools to make your life in Life is Feudal, a little less feudal.


## Installation ##

http://skunkfu.net/sf-mods/#installation


## Disclaimer ##

I am not responsible if you get banned for using this mod. Please use at your own risk.